define(['underscore', 'AbstractView', 'AbstractUIModel', 'text!component/SubmitButton/SubmitButton.html'], function (_, AV, UIModel, sbTemp) {
  return AV.extend({

    className: 'btn-submit',

    events: {
      'click': 'handleSubmit'
    },

    initialize: function ($super, options) {
      options = _.defaults({}, options, {

        text: '提交',

        color: '#fff',

        backgroundColor: ''

      });
      $super(options);

      _.extend(this, _.pick(options, [ 'text', 'color', 'backgroundColor' ]));

      this.loading = false;
      this.hasAnimation = false;
      this.template = _.template(sbTemp);
      this.uiModel = new UIModel({
        text: this.text,
        loading: this.loading
      });

      // loading状态变化，单独对单个元素操作
      this.listenTo(this.uiModel, 'change:loading', this.renderLoading.bind(this));

      this.render(this.uiModel);

      // 设置样式
      this.setAppearance({ color: this.color, backgroundColor: this.backgroundColor });
    },

    setAppearance: function (style) {
      this.$('.btn-submit-inner').css(style);
    },

    render: function (model) {
      this.$el.html(this.template(model.toJSON())).appendTo(this.$parent);
      this.$('.btn-submit-inner').toggleClass('loading', model.get('loading'));
    },

    renderLoading: function (_, loading) {
      this.$('.btn-submit-inner').toggleClass('loading', loading);
    },

    state: function (loading) {
      return loading == null
        ? this.uiModel.get('loading')
        : this.uiModel.set('loading', loading);
    },

    handleSubmit: function () {
      var loading = this.state();

      if (loading)
        return;

      this.state(true);
      this.trigger('onSubmit', this);
    }
  });
});
