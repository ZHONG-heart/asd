define(['underscore', 'AbstractView', 'text!component/Message/Message.html'], function (_, AV, messageTemp) {
  return AV.extend({
    className: 'message',

    template: _.template(messageTemp),

    initialize: function ($super, options) {
      options = _.defaults(options, {

        text: '全局提示',

        duration: 800,

        callbacks: {

          fadeIn: function () {
            setTimeout((function () {
              this.fade('out');
            }).bind(this), this.duration)
          },

          fadeOut: function () {
            this.remove();
          }

        }
      });

      $super(options);

      _.extend(this, _.pick(options, [ 'text', 'duration' ]));

      this.render();
      this.fade('in');
    },

    remove: function ($super) {
      $super();

      this.constructor.ins = null;
      return this;
    },

    render: function () {
      this.$el.html(this.template({ text: this.text })).appendTo(this.$parent);
    }
  })
});
