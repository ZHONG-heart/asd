define(['backbone', 'underscore'], function (Backbone, _) {
  var AppRoute = Backbone.Router.extend({
    initialize: function (options) {
      _.extend(this, options);
      this._bindRoutes();
    }
  });

  return function (options) {
    new AppRoute(options);
    //Backbone.history.start({ pushState: true, hashChange: false });
    Backbone.history.start();
  };
});
