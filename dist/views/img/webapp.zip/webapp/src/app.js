// 页面视图基础路径
var pagePath = 'src/view/page/';

define([
  'jquery',
  'buildClass',
  'src/router/route',
  pagePath + 'order/index.js',
  pagePath + 'wallet/recharge.js',
  'css!src/static/css/index.css',
  'css!src/static/css/order.css',
  'css!src/static/css/wallet.css'
], function ($, buildClass, route, OrderDetailView, WalletRechargeView) {

  function enterView (currViewKey, CurrView) {
    return function () {
      var currView = this.findViewByKey(currViewKey);
      var prevView = this.findViewByKey(this.prevViewKey);

      // 如果是返回\前进或者通过其他页进来
      if (currView) {
        currView.transverse('right', 'origin');
      } else {
        currView = this.initView(currViewKey, CurrView, { $parent: this.$wrapper });
        currView.transverse('right', 'origin');
      }

      if (prevView && currViewKey !== this.prevViewKey) {
        prevView.transverse('origin', 'left');
      }

      this.prevViewKey = currViewKey;
    }
  }

  // 定义应用程序
  var App = buildClass({

    initialize: function () {
      // 最外层容器
      this.$wrapper = $('<div></div>', { 'class': 'wrapper', style: 'position:relative;height: 100%;' }).appendTo(document.body);

      // 存储View对象
      this.views = {
        index: null,
        articleDetail: null
      };

      // 上一次显示的View名称，默认是首页
      this.prevViewKey = 'index';

      // 开启路由分发
      route({

        routes: {
          'order/detail': 'renderOrderDetail',
          'wallet/recharge': 'renderWalletRecharge'
        },

        renderOrderDetail: $.proxy(this.renderOrderDetail, this),

        renderWalletRecharge: $.proxy(this.renderWalletRecharge, this)

      });
    },

    // 初始化视图
    initView: function (viewId, View, options) {
      return this.views[viewId] = View.createInstance(options);
    },

    // 根据key获取视图
    findViewByKey: function (key) {
      return this.views[ key ];
    },

    // 跟单详情
    renderOrderDetail: enterView('orderDetail', OrderDetailView),

    // 钱包充值
    renderWalletRecharge: enterView('walletRecharge', WalletRechargeView)
  });

  return App;
});
