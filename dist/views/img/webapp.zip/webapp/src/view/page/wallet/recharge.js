define([
  'underscore',
  'jquery',
  'H5ConnectNative',
  'AbstractView',
  'AbstractUIModel',
  'Message',
  'text!'+ webRoot +'/src/template/wallet/recharge.html'], function (_, $, H5ConnectNative, AV, UIModel, MSG, rechargeTemp) {
  return AV.extend({

    id: 'wallet',

    className: 'page wallet',

    events: {
      'click .amount-item': 'selectAmount',
      'click .recharge-btn': 'recharge'
    },

    template: _.template(rechargeTemp),

    model: new UIModel({
      amount: 20,
      selectedIndex: 0,
      enabled: true
    }),

    initialize: function ($super, options) {
      $super(options);

      this.render();
      this.$('input').on('input', this.selectCustomAmount.bind(this));

      /* 初始化和原生交互条件 */
      this.h5ConnectNative = new H5ConnectNative();
    },

    selectAmount: function (e) {
      var $el = $(e.currentTarget),
          amount = parseFloat($el.find('label').html());

      $el.addClass('active').siblings().removeClass('active');
      this.$('input').val('');
      this.model.set({
        amount: amount,
        selectedIndex: $el.index(),
        enabled: true
      });
    },

    selectCustomAmount: function (e) {
      var amount = e.target.value,
          res = {};

      if (amount == '' || isNaN(+amount)) {
        res['amount'] = 0;
        res['selectedIndex'] = -1;
        res['enabled'] = false;
      } else {
        res['amount'] = +amount;
        res['selectedIndex'] = -1;
        res['enabled'] = true;
      }

      this.model.set(res);
    },

    recharge: function () {
      if (this.model.get('enabled')) {
        this.h5ConnectNative.goAppPage(
          JSON.stringify({
            amount: this.model.get('amount'),
            payType: 'ALIPAY'
          })
        );
        // var self = this;
        // var token = localStorage.getItem('accessToken') || 'cuiyaofei';
        // var domain = /^((https?:\/\/)?[^/]+)/.test(location.href) ? RegExp.$1 : '';
        // var data = _.extend(
        //   _.pick(this.model.toJSON(), 'amount', 'source'),
        //   { accessToken: token }
        // );
        //
        // self.model.set('enabled', false);
        //
        // $.ajax({
        //   url: (isLocal ? '' : '/api') + '/orders/recharge/submit',
        //   contentType: 'application/json;charset=utf-8',
        //   type: 'POST',
        //   dataType: 'json',
        //   data: JSON.stringify(data),
        //   success: function (resp) {
        //     if (resp.errcode != 0) {
        //       self.model.set('enabled', true);
        //       MSG.createInstance({ text: resp.errmsg });
        //       return;
        //     }
        //
        //     $.ajax({
        //       url: (isLocal ? '' : '/api') + '/orders/pre_pay',
        //       contentType: 'application/json;charset=utf-8',
        //       type: 'POST',
        //       dataType: 'json',
        //       data: JSON.stringify({
        //         orderId: resp.data.order.id,
        //         accessToken: token,
        //         payType: 'ALIPAY',
        //         payScene: 'H5',
        //         returnUrl: domain + '/#wallet/recharge?recharge=success'
        //       })
        //     })
        //
        //   },
        //   error: function () {
        //     self.model.set('enabled', true);
        //     MSG.createInstance({ text: '充值失败' });
        //   }
        // });
      }
    },

    changeAmount: function (model) {
      var selectedIndex = model.get('selectedIndex'),
          amount = model.get('amount'),
          enabled = model.get('enabled');

      if (selectedIndex < 0) {
        this.$('.amount-item').removeClass('active');
      } else {
        this.$('.amount-item').eq(selectedIndex).addClass('active').siblings().removeClass('active');
      }

      if (enabled) {
        this.$('.recharge-btn').removeClass('disabled').find('label').html(amount);
      } else {
        this.$('.recharge-btn').addClass('disabled').find('label').html('');
      }
    },

    render: function () {
      this.model.on('change', this.changeAmount, this);
      this.$el.html(this.template()).appendTo(this.$parent);
      this.changeAmount(this.model);
    }

  });

});
