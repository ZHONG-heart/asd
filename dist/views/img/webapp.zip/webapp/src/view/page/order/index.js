define([
  'underscore',
  'jquery',
  'H5ConnectNative',
  'AbstractView',
  'SubmitButton',
  'Message',
  'AbstractUIModel',
  ''+ webRoot +'/src/model/LotteryShop.js',
  'text!'+ webRoot +'/src/template/order/index.html'], function (
  _, $, H5ConnectNative,
  AV, SB, MSG,
  UIModel, LotteryShopModel,
  orderTemp) {

  var setPart = function (cost) {
    return function (e) {
      var part = cost
        ? parseFloat(this.fetchUIModel.get('multiple') == '' ? 0 : this.fetchUIModel.get('multiple')) + cost
        : e.target.value;

      this.fetchUIModel.set('multiple', part == 0 ? '' : String(part));
    }
  };

  return AV.extend({

    id: 'page_order',

    className: 'page',

    lotteryShopModel: new LotteryShopModel,

    productUIModel: new UIModel({

      // 方案号
      productId: 0,

      // 方案金额
      principal: '1',

      sendPrincipal: 1

    }),

    userUIModel: new UIModel({

      // 更单人
      name: '',

      // 微信号
      contactWechat: '',

      // QQ
      contactQq: '',

      // 手机号
      contactPhone: ''

    }),

    fetchUIModel: new UIModel({
      multiple: 1
    }),

    template: _.template(orderTemp),

    events: {
      'click .add': setPart(1),
      'click .sub': setPart(-1)
    },

    initialize: function ($super, options) {
      $super(options);

      var context = this;

      this.sbBtn = new SB({

        text: '提交彩店',

        backgroundColor: '#ed5b4e',

        color: '#fff'

      });
      this.msgPk = null;

      this.h5ConnectNative = new H5ConnectNative({

        setToken: function (accessToken) {
          localStorage.setItem('accessToken', JSON.stringify(accessToken));
        },

        getUserInfo: function (userInfo) {
          context.userUIModel.set(JSON.parse(userInfo));
        },

        getProductInfo: function (productInfo) {
          productInfo = JSON.parse(productInfo);
          productInfo.principal = String(productInfo.principal);
          context.productUIModel.set(productInfo);
          context.productUIModel.set('sendPrincipal', parseFloat(context.productUIModel.get('principal')));
          context.lotteryShopModel.fetch({ data: { productId: context.productUIModel.get('productId') }});
        }

      });

      this.listenTo(this.lotteryShopModel, 'change:shopName', this.renderLotteryShop);
      this.listenTo(this.userUIModel, 'change', this.renderUser);
      this.listenTo(this.productUIModel, 'change:productId', this.renderProductId);
      this.listenTo(this.productUIModel, 'change:principal', this.setPrincipal);
      this.listenTo(this.fetchUIModel, 'change:multiple', this.renderOrder);

      this.render();
      this._addInputEvent();
    },

    _sendLotteryShopInfo: function (sbBtnView) {
      var context = this;

      if (!this.lotteryShopModel.hasLiveShopId()) {
        context.msgPk = MSG.createInstance({ text: '出票彩店不能为空' });
        return;
      }

      $.ajax({
        url: (isLocal ? '' : '/api') + '/plan/indent/save',
        contentType: "application/json; charset=utf-8",
        type: 'post',
        dataType: 'json',
        data: JSON.stringify(_.extend({}, this._merge(this.lotteryShopModel), { type: 1, accessToken: JSON.parse(localStorage.getItem('accessToken')) })),
        success: function (resp) {
          sbBtnView.state(false);

          if (resp.errcode != 0) {
            context.msgPk = MSG.createInstance({ text: resp.errmsg });
            return;
          }

          context.h5ConnectNative.goAppPage(JSON.stringify({
            principal: context.productUIModel.get('principal'),
            orderId: resp.data.data,
            shopName: context.lotteryShopModel.get('shopName'),
            shopkeeperAlipay: context.lotteryShopModel.get('shopkeeperAlipay'),
            shopkeeperWeixin: context.lotteryShopModel.get('shopkeeperWeixin')
          }));
        },
        error: function () {
          sbBtnView.state(false);
          context.msgPk = MSG.createInstance({ text: '跟单失败' });
        }
      })
    },

    _merge: function () {
      var lotteryShopMap = this.lotteryShopModel.toJSON(),
          productMap = this.productUIModel.toJSON(),
          fetchMap = this.fetchUIModel.toJSON(),
          userMap = this.userUIModel.toJSON();

      return _.extend({}, lotteryShopMap, productMap, fetchMap, userMap);
    },

    _async: function (fn) {
      var args = [].slice.call(arguments, 1),
          context = this;

      setTimeout(function () {
        fn.apply(context, args);
      }, 400);
    },

    _addInputEvent: function () {
      this.$('.part-input').bind('input', setPart().bind(this));
    },

    setPrincipal: function (_, money) {
      this.$('.money').html(money);
    },

    renderProductId: function (_, productId) {
      this.$('.product-num').html(productId);
    },

    renderUser: function (userModel) {
      var name = userModel.get('name'),
          contactWechat = userModel.get('contactWechat'),
          contactQq = userModel.get('contactQq'),
          contactPhone = userModel.get('contactPhone');

      this.$('.username').children('label').html(name);
      this.$('.wechat-num').html(contactWechat);
      this.$('.qq').html(contactQq);
      this.$('.tel').html(contactPhone);
    },

    renderLotteryShop: function (_, shopName) {
      this.$('.shop-name').html(shopName);
    },

    render: function () {
      this.sbBtn.on('onSubmit', this._sendLotteryShopInfo, this);

      this.$el.html(this.template(this._merge()))
        .appendTo(this.$parent)
        .find('.req')
        .append(this.sbBtn.$el);
    },

    renderOrder: function (_, part) {
      this._renderOrderPart(part);
      this.productUIModel.set('principal', ( isNaN(part) ? /(\d+)/.test(part) ? RegExp.$1 : 0 : part == '' ? 0 : parseFloat(part)) * this.productUIModel.get('sendPrincipal'));
    },

    _validatePartError: function () {
      var part = this.fetchUIModel.get('multiple');

      if (part != null && part != '') {
        if (part < 1) {
          return 'min';
        } else if (part > 999) {
          return 'max';
        } else if (isNaN(part) || String(part).indexOf('.') >= 0) {
          return 'nan';
        }
      }

      return false;
    },

    _renderOrderPart: function (part) {
      var error = this._validatePartError();
      this.$('.part-input').val(part);

      if (error) {
        this._async(
          function (part) {
            this.fetchUIModel.set('multiple', part)
          },
          error === 'min' ? 1 : error === 'max' ? 999 : /(\d+)/.test(part) ? parseFloat(RegExp.$1) : 1
        );
      }
    }

  });
});
