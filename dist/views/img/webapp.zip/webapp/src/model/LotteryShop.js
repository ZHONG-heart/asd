define(['backbone', 'sync'], function (Bb) {
  return Bb.Model.extend({

    url: '/products/shop',

    defaults: function () {
      return {

        // 彩店id [必传]
        shopId: '',

        // 店名 [必传]
        shopName: '',

        // 支付宝账号 [必传]
        shopkeeperAlipay: '',

        // 微信账号 [必传]
        shopkeeperWeixin: ''

      };
    },

    parse: function (resp) {
      return {
        shopName: resp.shop.shopName,
        shopId: resp.shop.id,
        shopkeeperAlipay: resp.shop.shopkeeperAlipay,
        shopkeeperWeixin: resp.shop.shopkeeperWeixin
      };
    },

    hasLiveShopId: function () {
      return this.has('shopId');
    }
  });
});
